INSERT INTO division(nombre) VALUES ('1');
INSERT INTO division(nombre) VALUES ('2');
INSERT INTO division(nombre) VALUES ('Descens');
INSERT INTO division(nombre) VALUES ('Promoci');
