import { runInterpreter } from "./Parser";
console.log(runInterpreter("-1 1"))